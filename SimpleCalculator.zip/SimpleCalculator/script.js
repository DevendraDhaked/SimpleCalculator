function appendToDisplay(value){
    document.getElementById("input-box").value += value;
}

function clearDisplay(){
    document.getElementById("input-box").value = "";
}

function calculate(){
    let expression = document.getElementById("input-box").value;
    let result = eval(expression);
    document.getElementById("input-box").value = result;
}

function percentage(){
    let expression = document.getElementById("input-box").value;
    let res = (expression)/100;
    document.getElementById("input-box").value = res
}